package sample;

import javafx.scene.image.Image;

import java.util.Arrays;

public class Lesh extends Yen implements Cloneable {

    public Lesh() {

    }

    @Override
    protected Image getImageSelected() {
        return Main.imageActiveHero4;
    }

    protected Image getImageNonSelected() {
        return Main.imageLesh;
    }

    public Lesh(String name, int strength, int durability, double health) {
        this(name, strength, durability, health, Main.imageLesh);
    }

    public Lesh(String name, int strength, int durability, double health, Image image) {
        super(name, strength, durability, health, image);
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        Ciri tmp = new Ciri(get_name(), get_strength(), get_durability(), get_health());
        tmp.pointsOfRestore = Arrays.copyOf(this.pointsOfRestore, pointsOfRestore.length);
        return tmp;
    }

    @Override
    void bonus(Yen hero2) {
        hero2.set_coefficient(hero2.get_health() -0.4);
        System.out.println(get_name() + " збільшив коефіцієнт життя на 0.4 у " + hero2.get_name()
                + "; коефіцієнт зріс з " + (hero2.get_health() + 0.4) + " до " + hero2.get_health());
    }


    public static Lesh askParameters(String msg) {
        System.out.println(msg);

        System.out.print("Name:");
        String name = Main1.in.next();

        System.out.print("Fatigue:");
        String s = Main1.in.next();
        int durability = Integer.parseInt(s);

        System.out.print("Hours:");
        s = Main1.in.next();
        int strength = Integer.parseInt(s);

        System.out.print("Coefficient:");
        s = Main1.in.next();
        int health = Integer.parseInt(s);

        System.out.println();

        return new Lesh(name, durability, strength, health);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
