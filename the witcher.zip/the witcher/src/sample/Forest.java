package sample;

import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

import java.util.Arrays;
import java.util.Stack;
import java.util.concurrent.TimeUnit;

public class
Forest implements Place {

    Pane pane = new Pane();
    private long time = System.nanoTime();
    ImageView imageView = new ImageView();
    Image image = new Image("/sample/images/forest1.jpg", 365, 267, false, false);

    Label lableCountry = new Label();
    Label lableCount = new Label();
    Label lableNumberOfSick = new Label();
    int numberOfSick = 0;
    Yen[] objects = new Yen[0];

    public Forest() {
        lableCount.setText(String.valueOf(objects.length) + " героїв");
        lableCountry.setText("ліс Лешего");
        lableNumberOfSick.setText("Кількість: " + numberOfSick);
        imageView.setImage(image);

        lableCount.setLayoutX(10);
        lableCount.setLayoutY(10);
        lableCount.setTextFill(Color.AQUA);
        lableCountry.setLayoutX(10);
        lableCountry.setLayoutY(25);
        lableCountry.setTextFill(Color.AQUA);
        lableNumberOfSick.setLayoutY(40);
        lableNumberOfSick.setLayoutX(10);
        lableNumberOfSick.setTextFill(Color.AQUA);
        pane.getChildren().addAll(imageView, lableCount, lableCountry, lableNumberOfSick);
    }

    public void lifeCycle() {
        long now = System.nanoTime();
        Stack<Yen> toDelete = new Stack<>();
        if (!Valley.normalMode) {
            for (Yen p : objects) {
                Main.valley.add(p);
            }
            objects = new Yen[0];
            lableCount.setText(0 + " героїв");
        }  if (now - time >= TimeUnit.SECONDS.toNanos(1)) {
            time = now;
            numberOfSick++;
            lableNumberOfSick.setText(numberOfSick + "");
            for (Yen p : objects) {
                // if(!p.isActive)p.autoMove();
                if (!pane.boundsInParentProperty().get().contains(p.pane.getBoundsInParent())) {
                    toDelete.add(p);
                } else if (p.get_durability() >= Yen.DURABILITY_LIMIT) {
                    toDelete.add(p);
                } else {
                    p.set_durability(p.get_durability() + 1);
                    if (numberOfSick > 0) numberOfSick--;
                    lableNumberOfSick.setText(numberOfSick + "");
                }
            }
            for (Yen p : toDelete) {
                remove(p);
                p.autoMove();
                Main.valley.add(p);
            }
        }

    }

    public void add(Yen object, int pos) {
        Yen[] tmp = Arrays.copyOf(objects, objects.length + 1);
        for (int i = tmp.length - 1; i > pos; i--) {
            tmp[i] = tmp[i - 1];
        }
        tmp[pos] = object;
        objects = tmp;
    }

    public void add(Yen object) {
        Yen[] tmp = Arrays.copyOf(objects, objects.length + 1);
        tmp[objects.length] = object;
        objects = tmp;
        lableCount.setText(objects.length + " героїв");
        Main.labelWorld.setText("Кількість об'єктів: " + (Main.valley.Cave.objects.length + Main.valley.Forest.objects.length+ Main.valley.CaerMorchen.objects.length + Main.valley.objects.length));
    }

    public void remove(Yen hero2) {
        for (int i = 0; i < objects.length; i++) {
            if (objects[i].equals(hero2)) {
                remove(i);
                lableCount.setText(objects.length + " героїв");
                Main.labelWorld.setText("Кількість об'єктів: " + (Main.valley.Cave.objects.length + Main.valley.Forest.objects.length+Main.valley.CaerMorchen.objects.length + Main.valley.objects.length));
                break;
            }
        }

    }

    public void remove(int pos) {
        Yen[] tmp = new Yen[objects.length - 1];
        if (pos >= 0) System.arraycopy(objects, 0, tmp, 0, pos);
        if (objects.length - 1 - pos >= 0) System.arraycopy(objects, pos + 1, tmp, pos, objects.length - 1 - pos);
        objects = tmp;
    }

    @Override
    public String toString() {
        return "Forest:\n" +
                Arrays.toString(objects) +
                "\n";
    }
}
