package sample;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ReadObject {
    public static void main(String[] args)
    {
        try
        {
            FileInputStream fis = new FileInputStream("");
            ObjectInputStream ois = new ObjectInputStream(fis);

            Witcher hero = (Witcher) ois.readObject();
            Yen hero2 = (Yen) ois.readObject();
            Ciri hero3 = (Ciri) ois.readObject();
            Lesh hero4 = (Lesh) ois.readObject();

            System.out.println(hero);
            System.out.println(hero2);
            System.out.println(hero3);
            System.out.println(hero4);
            ois.close();
        }
        catch (IOException e )
        {
            System.out.println("Не робить , Да?");
        }
        catch (ClassNotFoundException e){
            System.out.println("Error3");
        }
    }
}
