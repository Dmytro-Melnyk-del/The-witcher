package sample;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.transform.Scale;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Main extends Application {
    public static Label labelWorld = new Label("Універсальний об'єкт");
    public static Label labelCharacter = new Label("Об'єкти не обрано!");
    public static Label labelMode = new Label("Активний режим: true");
    public static Group group = new Group();
    public static final int WIDTH = 2200;
    protected static ScrollPane scrollPane = new ScrollPane();
    protected static Scale scale = new Scale(0.1,0.1);
    public static final int HEIGHT = 2000;
    private static Scene scene;
    private HBox hBox = new HBox();
    protected static Image imageWorld;
    protected static ImageView imageViewWorld;
    protected static Stage stageWindow = new Stage();
    protected static Valley valley = new Valley();

    protected static Image imageActiveHero1 = new Image("/sample/images/hero1enabl.png", 170, 170, false, false);
    protected static Image imageActiveHero2 = new Image("/sample/images/hero2enabl.png", 450, 250, false, false);

    protected static Image imageActiveHero3 = new Image("/sample/images/hero3enabl.png", 400, 200, true, true);
    protected static Image imageActiveHero4 = new Image("/sample/images/lesh1.png", 400, 200, true, true);
    public static Image imageHero1 = new Image("/sample/images/hero1.png", 150, 150, false, false);
    public static Image imageHero2 = new Image("/sample/images/hero2.png", 400, 200, false, false);
    public static Image imageHero3 = new Image("/sample/images/hero3.png", 400, 200, false, false);
    public static Image imageLesh =new Image("/sample/images/lesh.png", 400, 200, false, false);

    @Override
    public void start(Stage primaryStage) throws Exception {
        //Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        BorderPane root = new BorderPane();
        imageWorld = new Image("/sample/images/valley.jpg",WIDTH,HEIGHT,false,false);
        imageViewWorld = new ImageView(imageWorld);
        group.getChildren().add(imageViewWorld);
        scrollPane = new ScrollPane(group);
        Yen hero2 = new Yen("herotwo1", 10, 95, 1000);
        hero2.pane.setLayoutX(150);
        hero2.pane.setLayoutY(150);
        Witcher hero = new Witcher("heroone1", 10, 15, 2000);
        hero.pane.setLayoutX(250);
        hero.pane.setLayoutY(250);
        Ciri hero3 = new Ciri("herotree1", 10, 95, 1500);
        hero3.pane.setLayoutX(350);
        hero3.pane.setLayoutY(350);
        Lesh hero4 = new Lesh("herofo1", 10100, 15000, 10000);
        hero4.pane.setLayoutX(1050);
        hero4.pane.setLayoutY(1050);

        imageViewWorld.setOnMouseClicked((e)->{
            System.out.println(e.getX()+" "+e.getY());
        });

        try
        {
            FileOutputStream oof = new FileOutputStream("Курсова.bin");
            ObjectOutputStream oos = new ObjectOutputStream(oof);
            oos.writeObject(hero);
            oos.writeObject(hero2);
            oos.writeObject(hero3);
            oos.writeObject(hero4);

            oos.close();

        }
        catch (IOException e ){
            System.out.println("Error1");
        }





        valley.add(hero);
        valley.add(hero2);
        valley.add(hero3);
        valley.add(hero4);
        valley.Forest.pane.setLayoutX(1400);
        valley.Forest.pane.setLayoutY(1400);
        valley.CaerMorchen.pane.setLayoutX(1135);
        valley.CaerMorchen.pane.setLayoutY(924);
        valley.Cave.pane.setLayoutX(1500);
        valley.Cave.pane.setLayoutY(400);


        group.getChildren().addAll(valley.Cave.pane, valley.CaerMorchen.pane,valley.Forest.pane,
                hero2.pane, hero.pane, hero3.pane,hero4.pane);
        root.setCenter(scrollPane);
        labelWorld.setText("Кількість мікрооб'єктів: "+(valley.Cave.objects.length+valley.Forest.objects.length+ valley.CaerMorchen.objects.length
                + valley.objects.length));
        root.setBottom(labelCharacter);
        hBox.getChildren().addAll(labelWorld,labelMode);
        hBox.setSpacing(10);
        root.setTop(hBox);
        group.getTransforms().add(scale);
        MiniMap miniMap = new MiniMap(group.snapshot(new SnapshotParameters(),null));
        group.getTransforms().remove(scale);
        AnimationTimer animationTimer = new AnimationTimer() {
            @Override
            public void handle(long l) {
                valley.lifeCycle();
                Main.update(miniMap);
            }
        };
        animationTimer.start();
        primaryStage.setTitle("The Witcher");
        scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        miniMap.getPane().setLayoutX(800-miniMap.getPane().getBoundsInParent().getWidth());
        miniMap.getPane().setLayoutY(18);
        root.getChildren().add(miniMap.getPane());
        scene.setOnKeyPressed(new KeyPressedHandler());
        primaryStage.show();
        primaryStage.widthProperty().addListener(((observableValue, number, t1) -> {
            miniMap.getPane().setLayoutX(t1.doubleValue()-miniMap.getPane().getBoundsInParent().getWidth()-30);
        }));
        scrollPane.viewportBoundsProperty().addListener(((observableValue, bounds, t1) -> {
            miniMap.getVisible().setLayoutX(-t1.getMinX()*scale.getX());
            miniMap.getVisible().setLayoutY(-t1.getMinY()*scale.getY());
            miniMap.getVisible().setWidth(t1.getWidth()*scale.getX());
            miniMap.getVisible().setHeight(t1.getHeight()*scale.getY());
        }));
    }

    public static void update(MiniMap miniMap){
        group.getTransforms().add(scale);
        miniMap.setImage(group.snapshot(new SnapshotParameters(),null));
        group.getTransforms().remove(scale);
    }

    public static void showWindow() throws IOException {
        Pane pane = FXMLLoader.load(Main.class.getResource("sample.fxml"));
        Scene sceneWindow = new Scene(pane,800,600);
        stageWindow.setScene(sceneWindow);
        stageWindow.show();
    }

    private class KeyPressedHandler implements EventHandler<KeyEvent> {
        @Override
        public void handle(KeyEvent event) {
            // Actions
            if(event.getCode().equals(KeyCode.ENTER)){
                try {
                    showWindow();
                } catch (IOException e) {
                    System.out.println("КВА КВА КВА");
                }
            }
            if(event.getCode().equals(KeyCode.L)){
                valley.normalMode= !valley.normalMode;
                labelMode.setText("Активний режим: "+ Valley.normalMode);
            }
            if(event.getCode().equals(KeyCode.DELETE)){
                for (Yen p : valley.objects) {
                    if(p.isActive){ valley.remove(p);
                        Main.group.getChildren().remove(p.pane);}
                }
                for (Yen p : valley.CaerMorchen.objects) {
                    if(p.isActive){ valley.CaerMorchen.remove(p);
                        Main.group.getChildren().remove(p.pane);}
                }
                for (Yen p : valley.Cave.objects) {
                    if(p.isActive) {
                        valley.Cave.remove(p);
                        Main.group.getChildren().remove(p.pane);
                    }
                }
                for (Yen p : valley.Forest.objects) {
                    if(p.isActive) {
                        valley.Forest.remove(p);
                        Main.group.getChildren().remove(p.pane);
                    }
                }
            }
            if (event.getCode().equals(KeyCode.ESCAPE)){
                for (Yen p : valley.objects) {
                    if(p.isActive) p.switchActive();
                }
                for (Yen p : valley.CaerMorchen.objects) {
                    if(p.isActive) p.switchActive();
                }
                for (Yen p : valley.Cave.objects) {
                    if(p.isActive) p.switchActive();
                }
                for (Yen p : valley.Forest.objects) {
                    if(p.isActive) p.switchActive();
                }
            }
            if (event.getCode().equals(KeyCode.A)) {
                for (Yen p : valley.objects) {
                    System.out.println(p);
                    p.left();
                }
                for (Yen p : valley.CaerMorchen.objects) {
                    System.out.println(p);
                    p.left();
                }
                for (Yen p : valley.Cave.objects) {
                    System.out.println(p);
                    p.left();
                }
                for (Yen p : valley.Forest.objects) {
                    System.out.println(p);
                    p.left();
                }
                System.out.println("LEFT");
            }

            if (event.getCode().equals(KeyCode.D)) {
                for (Yen p : valley.objects) {
                    System.out.println(p);
                    p.right();
                }
                for (Yen p : valley.CaerMorchen.objects) {
                    System.out.println(p);
                    p.right();
                }
                for (Yen p : valley.Cave.objects) {
                    System.out.println(p);
                    p.right();
                }
                for (Yen p : valley.Forest.objects) {
                    System.out.println(p);
                    p.right();
                }
                System.out.println("RIGHT");
            }

            if (event.getCode().equals(KeyCode.W)) {
                for (Yen p : valley.objects) {
                    System.out.println(p);
                    p.up();
                }
                for (Yen p : valley.CaerMorchen.objects) {
                    System.out.println(p);
                    p.up();
                }
                for (Yen p : valley.Cave.objects) {
                    System.out.println(p);
                    p.up();
                }
                for (Yen p : valley.Forest.objects) {
                    System.out.println(p);
                    p.up();
                }
                System.out.println("UP");
            }

            if (event.getCode().equals(KeyCode.S)) {
                for (Yen p : valley.objects) {
                    System.out.println(p);
                    p.down();
                }
                for (Yen p : valley.CaerMorchen.objects) {
                    System.out.println(p);
                    p.down();
                }
                for (Yen p : valley.Cave.objects) {
                    System.out.println(p);
                    p.down();
                }
                for (Yen p : valley.Forest.objects) {
                    System.out.println(p);
                    p.down();
                }
                System.out.println("DOWN");
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
