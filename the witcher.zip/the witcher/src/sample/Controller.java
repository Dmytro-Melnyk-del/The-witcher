package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    @FXML
    private Button button1;

    @FXML
    private Label labelWelcome;

    @FXML
    private RadioButton hero2Button;

    @FXML
    private ToggleGroup button;

    @FXML
    private RadioButton hero1Button;

    @FXML
    private RadioButton hero3Button;

    @FXML
    private TextField nameField;

    @FXML
    private TextField durabilityField;

    @FXML
    private TextField strengthField;

    @FXML
    private TextField healthField;

    @FXML
    private RadioButton worldButton;

    @FXML
    private ToggleGroup button2;

    @FXML
    private RadioButton CaerButton;

    @FXML
    private RadioButton CaveButton;

    @FXML
    private RadioButton ForestButton;


    @FXML
    void create(ActionEvent event) {
        if (hero2Button.isSelected()) {
            Yen hero2 = new Yen(nameField.getText(),
                    Integer.parseInt(strengthField.getText()),
                    Integer.parseInt(durabilityField.getText()),
                    Double.parseDouble(healthField.getText()));
            if (worldButton.isSelected()) {
                hero2.pane.setLayoutX(50);
                hero2.pane.setLayoutY(50);
                Main.valley.add(hero2);
                Main.group.getChildren().add(hero2.pane);
            } else if (CaerButton.isSelected()) {
                hero2.pane.setLayoutX(1135);
                hero2.pane.setLayoutY(924);
                Main.valley.CaerMorchen.add(hero2);
                Main.group.getChildren().add(hero2.pane);
            } else if (CaveButton.isSelected()) {
                hero2.pane.setLayoutX(1500);
                hero2.pane.setLayoutY(401);
                Main.valley.Cave.add(hero2);
                Main.group.getChildren().add(hero2.pane);
            }
            else if (ForestButton.isSelected()) {
                hero2.pane.setLayoutX(1400);
                hero2.pane.setLayoutY(1400);
                Main.valley.Forest.add(hero2);
                Main.group.getChildren().add(hero2.pane);
            }
        } else if (hero1Button.isSelected()) {
            Witcher hero = new Witcher(nameField.getText(),
                    Integer.parseInt(strengthField.getText()),
                    Integer.parseInt(durabilityField.getText()),
                    Double.parseDouble(healthField.getText()));
            if (worldButton.isSelected()) {
                hero.pane.setLayoutX(50);
                hero.pane.setLayoutY(50);
                Main.valley.add(hero);
                Main.group.getChildren().add(hero.pane);
            } else if (CaerButton.isSelected()) {
                hero.pane.setLayoutX(1135);
                hero.pane.setLayoutY(924);
                Main.valley.CaerMorchen.add(hero);
                Main.group.getChildren().add(hero.pane);
            } else if (CaveButton.isSelected()) {
                hero.pane.setLayoutX(1500);
                hero.pane.setLayoutY(401);
                Main.valley.Cave.add(hero);
                Main.group.getChildren().add(hero.pane);
            } else if (ForestButton.isSelected()) {
                hero.pane.setLayoutX(1400);
                hero.pane.setLayoutY(1400);
                Main.valley.Forest.add(hero);
                Main.group.getChildren().add(hero.pane);
            }
        } else if (hero3Button.isSelected()) {
            Ciri headDoctor = new Ciri(nameField.getText(),
                    Integer.parseInt(strengthField.getText()),
                    Integer.parseInt(durabilityField.getText()),
                    Double.parseDouble(healthField.getText()));
            if (worldButton.isSelected()) {
                Main.valley.add(headDoctor);
                headDoctor.pane.setLayoutX(50);
                headDoctor.pane.setLayoutY(50);
                Main.group.getChildren().add(headDoctor.pane);
            } else if (CaerButton.isSelected()) {
                Main.valley.CaerMorchen.add(headDoctor);
                headDoctor.pane.setLayoutX(1135);
                headDoctor.pane.setLayoutY(924);
                Main.group.getChildren().add(headDoctor.pane);
            } else if (CaveButton.isSelected()) {
                Main.valley.Cave.add(headDoctor);
                headDoctor.pane.setLayoutX(1500);
                headDoctor.pane.setLayoutY(401);
                Main.group.getChildren().add(headDoctor.pane);
            } else if (ForestButton.isSelected()) {
                headDoctor.pane.setLayoutX(1400);
                headDoctor.pane.setLayoutY(1400);
                Main.valley.Forest.add(headDoctor);
                Main.group.getChildren().add(headDoctor.pane);
            }
        }
        Main.stageWindow.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }
}
