package sample;

public interface Place {
    public void add(Yen hero2);
}
