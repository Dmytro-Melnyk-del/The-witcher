package sample;

import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Stack;

public class Main1 {

    public static Scanner in = new Scanner(System.in);
    public static Valley valley = new Valley();

    public static void main(String[] args) throws CloneNotSupportedException {
        Yen hero2 = new Yen("John", 10, 50, 3);
        Witcher hero = new Witcher( "Tom", 10, 30, 5.2);
        Ciri hero3 = new Ciri("Jerry", 10, 45, 7.1);
        Lesh hero4 = new Lesh("John", 10, 50, 3);
        hero2.print();
        hero.print();
        hero4.print();
        hero3.print();
        valley.place.get("CaerMorchen").add(hero2);
        valley.place.get("Cave").add(hero);
        valley.add(hero3);
        valley.place.get("Forest").add(hero4);

        valley.place.get("CaerMorchen").add(new Yen("herotwo1", 10, 10, 10));
        valley.place.get("CaerMorchen").add(new Witcher("heroone1", 11, 11, 10.2));
        valley.place.get("CaerMorchen").add(new Ciri("herotree1", 12, 12, 12));
        valley.place.get(("Forest")).add(new Lesh("herotree1", 12, 12, 12));
        valley.place.get("Cave").add(new Yen("herotwo2", 13, 13, 10.2));
        valley.place.get("Cave").add(new Witcher("heroone2", 14, 14, 14));
        valley.place.get("Cave").add(new Ciri("herotree2", 15, 15, 15));
        valley.add(new Yen("herotwo3", 16, 16, 10.2));
        valley.add(new Witcher("heroone3", 17, 17, 17));
        valley.add(new Ciri("herotree3", 18, 18, 18));
        menu();
    }

    private static void menu() throws CloneNotSupportedException {
        boolean flag = true;
        while (flag) {
            System.out.println("********************");
            System.out.println("1 - створити новий об'єкт");
            System.out.println("2 - вивести на екран зміст універсального об'єкту");
            System.out.println("3 - взаємодія мікрооб'єктів (тренінг)");
            System.out.println("4 - взаємодія макрооб'єктів (програма обміну)");
            System.out.println("5 - підрахунок мікрооб'єктів");
            System.out.println("6 - видалити мікрооб'єкт");
            System.out.println("7 - вихід");
            System.out.println("********************");
            int n = in.nextInt();
            switch (n) {
                case 1:
                    create();
                    break;
                case 2:
                    System.out.println(valley);
                    break;
                case 3:
                    bonusByName();
                    break;
                case 4:
                    Yen[] tmp = valley.CaerMorchen.objects;
                    valley.CaerMorchen.objects = valley.Cave.objects;
                    valley.Cave.objects = tmp;
                    System.out.println("Програму обміну завершено!");
                    break;
                case 5:
                    chooseCount();
                    break;
                case 6:
                    delete();
                    System.out.println("Мікрооб'єкт було успішно видалено!");
                    break;
                case 7:
                    flag = false;
                    System.out.println("Програму завершено!");
                    break;
            }
        }

    }

    private static void chooseCount(){
        System.out.println("1 - за кількістю сили\n" +
                "2 - за рівнем витривалосты\n" +
                "3 - за коефіцієнтом здоров'я");
        int param = in.nextInt();
        System.out.println("Введіть дані для пошуку: ");
        if(param == 1){
            int tmpstrength = in.nextInt();
            count(tmpstrength, param);
        } else if (param == 2){
            int tmpdurability = in.nextInt();
            count(tmpdurability, param);
        } else if(param == 3){
            double tmphealth = in.nextDouble();
            count(tmphealth);
        }
    }

    private static void count(int n, int param){
        String level;
        Stack<String> stack = new Stack<>();
        if (param == 1){
            for(Yen p : valley.objects){
                if (p.get_strength() == n){
                    if (p instanceof Ciri) level = "Герой 3-го рівня";
                    else if(p instanceof Witcher) level = "Герой 1-го рівня";
                    else level = "Герой 2-го рівня";
                    stack.add("Універсальний об'єкт, " + level + ", "+ p);
                }
            }
            for(Yen p : valley.CaerMorchen.objects){
                if (p.get_strength() == n){
                    if (p instanceof Ciri) level = "Герой 3-го рівня";
                    else if(p instanceof Witcher) level = "Герой 1-го рівня";
                    else level = "Герой 2-го рівня";
                    stack.add("Табір, " + level + ", "+ p);
                }
            }
            for(Yen p : valley.Cave.objects){
                if (p.get_strength() == n){
                    if (p instanceof Ciri) level = "Герой 3-го рівня";
                    else if(p instanceof Witcher) level = "Герой 1-го рівня";
                    else level = "Герой 2-го рівня";
                    stack.add("печера Беса, " + level + ", "+ p);
                }
            }
            System.out.println("Кількість відповідних об'єктів: "+stack.size());
            System.out.println(stack);
        } else if (param == 2){
            for(Yen p : valley.objects){
                if (p.get_durability() == n){
                    if (p instanceof Ciri) level = "Герой 3-го рівня";
                    else if(p instanceof Witcher) level = "Герой 1-го рівня";
                    else level = "Герой 2-го рівня";
                    stack.add("Універсальний об'єкт, " + level + ", "+ p);
                }
            }
            for(Yen p : valley.CaerMorchen.objects){
                if (p.get_durability() == n){
                    if (p instanceof Ciri) level = "Герой 3-го рівня";
                    else if(p instanceof Witcher) level = "Герой 1-го рівня";
                    else level = "Герой 2-го рівня";
                    stack.add("Каер - Морхен, " + level + ", "+ p);
                }
            }
            for(Yen p : valley.Cave.objects){
                if (p.get_durability() == n){
                    if (p instanceof Ciri) level = "Герой 3-го рівня";
                    else if(p instanceof Witcher) level = "Герой 1-го рівня";
                    else level = "Герой 2-го рівня";
                    stack.add("печера Беса, " + level + ", "+ p);
                }
            }
            System.out.println("Кількість відповідних об'єктів: "+stack.size());
            System.out.println(stack);
        }
    }

    private static void count(double n){
        String level;
        PriorityQueue<String> priorityQueue = new PriorityQueue<>();
        for(Yen p : valley.objects){
            if (p.get_health() == n){
                if (p instanceof Ciri) level = "Герой 3-го рівня";
                else if(p instanceof Witcher) level = "Герой 1-го рівня";
                else level = "Герой 2-го рівня";
                priorityQueue.add("Універсальний об'єкт, " + level + ", "+ p);
            }
        }
        for(Yen p : valley.CaerMorchen.objects){
            if (p.get_health() == n){
                if (p instanceof Ciri) level = "Герой 3-го рівня";
                else if(p instanceof Witcher) level = "Герой 1-го рівня";
                else level = "Герой 2-го рівня";
                priorityQueue.add("Каер - Морхен, " + level + ", "+ p);
            }
        }
        for(Yen p : valley.Cave.objects){
            if (p.get_health() == n){
                if (p instanceof Ciri) level = "Герой 3-го рівня";
                else if(p instanceof Witcher) level = "Герой 1-го рівня";
                else level = "Герой 2-го рівня";
                priorityQueue.add("печера Беса, " + level + ", "+ p);
            }
        }
        System.out.println("Кількість відповідних об'єктів: "+priorityQueue.size());
        System.out.println(priorityQueue);
    }

    private static void delete() {
        System.out.println(valley);
        System.out.println("Оберіть, де потрібно видалити мікрооб'єкт " +
                "\n1 - Ліс Лешего;" +
                "\n2 - Каер - Морхен;" +
                "\n3 - печера Беса. ");
        int param = in.nextInt();
        System.out.println("Вкажіть індекс елементу відносно місця його перебування (нумерація починається з нуля): ");
        int index = in.nextInt();
        if (param == 1) {
            valley.remove(index);
        } else if (param == 2) {
            valley.CaerMorchen.remove(index);
        } else if (param == 3) {
            valley.Cave.remove(index);
        }
    }

    private static void bonusByName() throws CloneNotSupportedException {
        Arrays.sort(valley.objects, Yen.NameComparator);

        Arrays.sort(valley.CaerMorchen.objects, Yen.NameComparator);
        Arrays.sort(valley.Cave.objects, Yen.NameComparator);
        System.out.println(valley);
        System.out.println("Де знаходиться мікрооб'єкт, який буде допомагати іншим?" +
                "\n1 - Ліс Лешего;" +
                "\n2 - Каер - Морхен;" +
                "\n3 - печера Беса. ");
        int countryParam = in.nextInt();
        System.out.println("Впишіть ім'я мікрооб'єкта ");
        String name = in.next();
        System.out.println("Оберіть, де проведе допомогу мікрооб'єкт " +
                "\n1 - Ліс Лешего;" +
                "\n2 - Каер - Морхен;" +
                "\n3 - печера Беса. ");
        int lectionParam = in.nextInt();
        if (countryParam == 1) {
            Yen tmpObj = new Yen(name);
            int pos = Arrays.binarySearch(valley.objects, tmpObj, Yen.NameComparator);
            if (pos < 0) System.out.println("Об'єкт не знайдено!");
            else {
                if (lectionParam == 1) {
                    for (Yen p : valley.objects) {
                        valley.objects[pos].bonus(p);
                    }
                } else if (lectionParam == 2) {

                    for (Yen p : valley.CaerMorchen.objects) {
                        valley.objects[pos].bonus(p);
                    }
                } else if (lectionParam == 3) {
                    for (Yen p : valley.Cave.objects) {
                        valley.objects[pos].bonus(p);
                    }
                }
            }

        } else if (countryParam == 2) {
            Yen tmpObj = new Yen(name);
            int pos = Arrays.binarySearch(valley.CaerMorchen.objects, tmpObj, Yen.NameComparator);
            if (pos < 0) System.out.println("Об'єкт не знайдено!");
            else {
                if (lectionParam == 1) {
                    for (Yen p : valley.objects) {
                        valley.CaerMorchen.objects[pos].bonus(p);
                    }
                } else if (lectionParam == 2) {
                    for (Yen p : valley.CaerMorchen.objects) {
                        valley.CaerMorchen.objects[pos].bonus(p);
                    }
                } else if (lectionParam == 3) {
                    for (Yen p : valley.Cave.objects) {
                        valley.CaerMorchen.objects[pos].bonus(p);
                    }
                }
            }

        } else if (countryParam == 3) {
            Yen tmpObj = new Yen(name);
            int pos = Arrays.binarySearch(valley.Cave.objects, tmpObj, Yen.NameComparator);
            if (pos < 0) System.out.println("Об'єкт не знайдено!");
            else {
                if (lectionParam == 1) {
                    for (Yen p : valley.objects) {
                        valley.Cave.objects[pos].bonus(p);
                    }
                } else if (lectionParam == 2) {
                    for (Yen p : valley.CaerMorchen.objects) {
                        valley.Cave.objects[pos].bonus(p);
                    }
                } else if (lectionParam == 3) {
                    for (Yen p : valley.Cave.objects) {
                        valley.Cave.objects[pos].bonus(p);
                    }
                }
            }
        }
    }

    private static void create() {
        System.out.println("Оберіть рівень успадкування класа:\n" +
                "1 - 1 рівень;\n" +
                "2 - 2 рівень;\n" +
                "3 - 3 рівень.");
        int param1 = in.nextInt();
        System.out.println("Оберіть, куди додати об'єкт:\n" +
                "1 - Каер - Морхен;\n" +
                "2 - печера Беса;\n" +
                "3 - Ліс Лешого.");
        int param2 = in.nextInt();
        if (param1 == 1 && param2 == 1) {
            valley.place.get("Каер - Морхен").add(Yen.askParameters("Введіть параметри для створення нового героя 2-го рівня:"));
        } else if (param1 == 2 && param2 == 1) {
            valley.place.get("Каер - Морхен").add(Witcher.askParameters("Введіть параметри для створення нового героя 1-го рівня:"));
        } else if (param1 == 3 && param2 == 1) {
            valley.place.get("Каер - Морхен").add(Ciri.askParameters("Введіть параметри для створення нового героя 2-го рівня:"));
        } else if (param1 == 1 && param2 == 2) {
            valley.place.get("печера Беса").add(Yen.askParameters("Введіть параметри для створення нового лиходія 2-го рівня:"));
        } else if (param1 == 2 && param2 == 2) {
            valley.place.get("печера Беса").add(Witcher.askParameters("Введіть параметри для створення нового лиходія 1-го рівня:"));
        } else if (param1 == 3 && param2 == 2) {
            valley.place.get("печера Беса").add(Ciri.askParameters("Введіть параметри для створення нового лиходія 3-го рівня:"));
        } else if (param1 == 1 && param2 == 3) {
            valley.add(Yen.askParameters("Введіть параметри для створення нового героя 2-го рівня:"));
        } else if (param1 == 2 && param2 == 3) {
            valley.add(Witcher.askParameters("Введіть параметри для створення нового героя 1-го рівня:"));
        } else if (param1 == 3 && param2 == 3) {
            valley.add(Ciri.askParameters("Введіть параметри для створення нового героя 2-го рівня:"));
        }
    }
}
