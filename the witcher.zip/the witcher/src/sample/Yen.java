package sample;

import javafx.geometry.Bounds;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
import java.util.Random;

public class Yen implements Cloneable {

    private int durability, strength;
    protected boolean isActive = false;
    private double health;
    private String name;
    protected long time = System.nanoTime();
    protected int[] pointsOfRestore = new int[0];
    public Pane pane = new Pane();
    public ImageView imageView = new ImageView();
    public Label labelName = new Label();
    public Label labeldurability = new Label();
    public Label labelhealth = new Label();
    protected final static int DURABILITY_LIMIT=100;
    protected int step = 2;
    private int aimX;
    private int aimY;
    //private static double cure = 0;

    {
        pane.setOnMouseClicked((e)->{
            switchActive();
            Main.labelCharacter.setText(this.toString());
            System.out.println(this.toString() + isActive);
        });
    }

    public void lifeCycle(){
        autoMove();
    }

    public void autoMove(){

        if (aimX == pane.getLayoutX() && aimY == pane.getLayoutY()) {
            Random rnd = new Random();
            aimX = rnd.nextInt(Main.WIDTH - (int)pane.getBoundsInParent().getWidth());
            aimY = rnd.nextInt(Main.HEIGHT - (int)pane.getBoundsInParent().getHeight());
        }

        double dx = aimX - pane.getLayoutX();
        double dy = aimY - pane.getLayoutY();
        dx = Math.abs(dx) > step?Math.signum(dx)*step:dx;
        dy = Math.abs(dy) > step?Math.signum(dy)*step:dy;


        pane.setLayoutX(pane.getLayoutX() + dx);
        pane.setLayoutY(pane.getLayoutY() + dy);
    }

    protected void switchActive() {
        isActive = !isActive;
        if(isActive){
            imageView.setImage(getImageSelected());
        } else{
            imageView.setImage(getImageNonSelected());
        }

    }

    protected Image getImageSelected() {
        return Main.imageActiveHero2;
    }

    protected Image getImageNonSelected() {
        return Main.imageHero2;
    }

    public Yen(String name, int strength, int durability, double health) {
        this(name,strength,durability,health,Main.imageHero2);
    }

    public Yen(String name, int strength, int durability, double health, Image image) {
        this.name = name;
        this.strength = strength;
        this.health = health;
        this.durability = durability;
        this.imageView.setImage(image);
        this.labelName.setText(name);
        this.labelName.setTextFill(Color.AQUA);
        labelName.setLayoutX(50);
        //this.labelName.setLayoutX(-15);
        labelhealth.setText(String.valueOf(health));
        labelhealth.setLayoutY(15);
        labelhealth.setLayoutX(50);
        this.labelhealth.setTextFill(Color.RED);
        pane.getChildren().addAll(imageView,labelName,labeldurability,labelhealth);
    }

    public Yen(String s, int durability, int strength) {
        name = s;
        this.durability = durability;
        this.health = strength;
        health = 1;
        System.out.println("Виклик конструктора класу Героя!");
        System.out.println("Ім'я: " + name);
        System.out.println("Рівень витривалості: " + durability);
        System.out.println("Кількість сили: " + strength);
        System.out.println("Коефіцієнт життя: " + health);
    }

//    {
//        System.out.println("Створення нового об'єкта класу Paramedic (Non-static initial)");
//    }

    public Yen(String name) {
        this.name = name;
    }

    public Yen(int strength) {
        this.strength = strength;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() +
                " durability=" + durability +
                ", strength=" + strength +
                ", health=" + health +
                ", name='" + name + '\'' +
                ", pointsOfRestore=" + Arrays.toString(pointsOfRestore) +
                "\n";
    }

    public void left() {
        if (!isActive) return;
        double dx = pane.getLayoutX() - step;
        Bounds bounds = Main.imageViewWorld.getBoundsInParent();
        System.out.println(bounds + " " + pane.getBoundsInParent());
        if (Main.imageViewWorld.getBoundsInParent().contains(dx, pane.getLayoutY())) {
            pane.setLayoutX(pane.getLayoutX() - step);
        }
        else
            pane.setLayoutX(0);
    }

    public void right() {
        if (!isActive) return;
        double width = pane.boundsInParentProperty().get().getWidth();
        double dx = pane.getLayoutX() + step;
        Bounds bounds = Main.imageViewWorld.getBoundsInParent();
        System.out.println(bounds + " " + pane.getBoundsInParent());
        if (Main.imageViewWorld.getBoundsInParent().contains(dx+width, pane.getLayoutY())) {
            pane.setLayoutX(pane.getLayoutX() + step);
        }
//        else
////            pane.setLayoutX();
    }

    public void up() {
        if (!isActive) return;
        double dy = pane.getLayoutY() - step;
        if (Main.imageViewWorld.getBoundsInParent().contains(pane.getLayoutX(),dy)) {
            pane.setLayoutY(pane.getLayoutY() - step);
        }
    }

    public void down() {
        if (!isActive) return;
        System.out.println(pane.boundsInParentProperty().get().getHeight());
        double dy = pane.getLayoutY() + step+pane.boundsInParentProperty().get().getHeight();
        if (Main.imageViewWorld.getBoundsInParent().contains(pane.getLayoutX(), dy)) {
            pane.setLayoutY(pane.getLayoutY() + step);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Yen hero2 = (Yen) o;
        return durability == hero2.durability && strength == hero2.strength && Double.compare(hero2.health, health) == 0 && Objects.equals(name, hero2.name) && Arrays.equals(pointsOfRestore, hero2.pointsOfRestore);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(durability, strength, health, name);
        result = 31 * result + Arrays.hashCode(pointsOfRestore);
        return result;
    }

//    static {
//        System.out.println("Створення першого об'єкта класу Paramedic (Static initial)");
//    }

    public Yen() {
        System.out.println("Створення нового об'єкту без параметрів!");
    }

    void set_name(String s) {
        name = s;
    }

    String get_name() {
        return name;
    }

    void set_coefficient(double n) {
        health =n;
        labelhealth.setText(String.format("%.2f",n));
    }

    double get_health() {
        return health;
    }

    void set_durability(int n) {
        durability = n;
       //labeldurability.setText("Рівень втоми: "+durability);
    }

    int get_durability() {
        return durability;
    }

    void set_strength(int n) {
        strength = n;
    }

    int get_strength() {
        return strength;
    }

    public void shift() {
        strength += 24;
        durability += 10;
    }



    void bonus(Yen hero2) {
        if (hero2 instanceof Witcher) {
            System.out.println(this.name+ " нічому не навчив "+ hero2.get_name()+" більш вищого рівня");
        } else {
            hero2.set_coefficient(get_health()-0.2);
            hero2.labelhealth.setText(String.valueOf(hero2.health));
            System.out.println(this.name + " збільшив коефіцієнт життя на 0.02 у " + hero2.name
                    + "; коефіцієнт зріс з " + (hero2.health + 0.02) + " до " + hero2.health);
        }
    }

    public static Comparator<Yen> NameComparator = Comparator.comparing(o -> o.name);

    void restore() {
        durability -= 50;
        int[] tmp = Arrays.copyOf(pointsOfRestore, pointsOfRestore.length + 1);
        tmp[pointsOfRestore.length] = strength;
        pointsOfRestore = tmp;
    }


    void print() {
        System.out.printf("Name - %s, durability - %d, strength - %d, health - %f, Points of restore -%s\n",
                name, durability, strength, health, Arrays.toString(pointsOfRestore));

    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        Yen tmp = new Yen(name, strength, durability, health);
        tmp.pointsOfRestore = Arrays.copyOf(this.pointsOfRestore, pointsOfRestore.length);
        return tmp;
    }

    public static Yen askParameters(String msg) {
        System.out.println(msg);

        System.out.print("Name:");
        String name = Main1.in.next();

        System.out.print("durability:");
        String s = Main1.in.next();
        int durability = Integer.parseInt(s);

        System.out.print("strength:");
        s = Main1.in.next();
        int strength = Integer.parseInt(s);

        System.out.print("health:");
        s = Main1.in.next();
        int health = Integer.parseInt(s);

        System.out.println();
        return new Yen(name, durability, strength, health);
    }

    public void changeParameters() {
        System.out.print("Name: ");
        name = Main1.in.next();
        System.out.print("durability: ");
        durability = Main1.in.nextInt();
        System.out.print("strength: ");
        strength = Main1.in.nextInt();
    }

    public static class HoursComparator implements Comparator<Yen> {

        @Override
        public int compare(Yen o1, Yen o2) {
            if (o1.strength < o2.strength) return -1;
            if (o1.strength > o2.strength) return 1;
            return 0;
        }
    }
}
