package sample;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class MiniMap {

    private ImageView imageViewSmall;
    private Rectangle outline = new Rectangle();
    private Rectangle visible = new Rectangle();
    private Pane pane = new Pane();

    public MiniMap(Image image){
        imageViewSmall = new ImageView(image);
        double W = imageViewSmall.getBoundsInParent().getWidth();
        double H = imageViewSmall.getBoundsInParent().getHeight();
        outline.setWidth(W);
        outline.setHeight(H);
        outline.setFill(Color.TRANSPARENT);
        outline.setStrokeWidth(2);
        outline.setStroke(Color.RED);
        visible.setWidth(W/10);
        visible.setHeight(H/10);
        visible.setFill(Color.TRANSPARENT);
        visible.setStrokeWidth(2);
        visible.setStroke(Color.GREEN);
        pane.getChildren().addAll(outline,imageViewSmall,visible);
    }

    {
        pane.setOnMouseClicked((mouseEvent -> {
            Main.scrollPane.hvalueProperty().set(mouseEvent.getX()/pane.getBoundsInParent().getWidth());
            Main.scrollPane.vvalueProperty().set(mouseEvent.getY()/pane.getBoundsInParent().getHeight());
        }));
    }

    public void setImage(WritableImage writableImage){
        imageViewSmall.setImage(writableImage);
    }


    public Pane getPane() {
        return pane;
    }

    public Rectangle getVisible(){
        return visible;
    }

    public void setPane(Pane pane) {
        this.pane = pane;
    }
}
