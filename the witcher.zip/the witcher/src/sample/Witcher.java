package sample;

import javafx.scene.image.Image;

import java.util.Arrays;

public class Witcher extends Yen implements Cloneable{

    public Witcher(){

    }

    @Override
    protected Image getImageSelected() {
        return Main.imageActiveHero1;
    }

    protected Image getImageNonSelected() {
        return Main.imageHero1;
    }

    public Witcher(String name, int strength, int durability, double health, Image image) {
        super(name,strength,durability,health,image);
    }

    public Witcher(String name, int strength, int durability, double health){
        this(name,strength,durability,health,Main.imageHero1);
    }

    

    @Override
    protected Object clone() throws CloneNotSupportedException {
        Witcher tmp = new Witcher(get_name(),get_strength(),get_durability(),get_health());
        tmp.pointsOfRestore= Arrays.copyOf(this.pointsOfRestore,pointsOfRestore.length);
        return tmp;
    }

    @Override
    void bonus(Yen hero2) {
        if (hero2 instanceof Yen) {
            System.out.println(get_name()+ " нічому не навчив "+ hero2.get_name()+" більш вищого рівня");
        } else {
            hero2.set_coefficient(hero2.get_health()-0.3);
            System.out.println(get_name() + " збільшив коефіцієнт майстерності на 0.3 у " + hero2.get_name()
                    + "; коефіцієнт зріс з " + (hero2.get_health() + 0.3) + " до " + hero2.get_health());
        }
    }
    public static Witcher askParameters(String msg) {
        System.out.println(msg);

        System.out.print("Name:");
        String name = Main1.in.next();

        System.out.print("Fatigue:");
        String s = Main1.in.next();
        int durability = Integer.parseInt(s);

        System.out.print("Hours:");
        s = Main1.in.next();
        int strength = Integer.parseInt(s);

        System.out.print("Coefficient:");
        s = Main1.in.next();
        int health = Integer.parseInt(s);

        System.out.println();

        return new Witcher(name, durability, strength, health);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
