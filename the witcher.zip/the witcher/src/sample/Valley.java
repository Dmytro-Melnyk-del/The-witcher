package sample;

import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.geometry.Bounds;

import java.util.*;
import java.util.concurrent.TimeUnit;

public class Valley {

    protected static boolean normalMode = true;
    final CaerMorchen CaerMorchen = new CaerMorchen();
    final Cave Cave = new Cave();
    final  Forest Forest = new Forest();

    Map<String, Place> place = new HashMap<>();
    Yen[] objects = new Yen[0];
    private long time = System.nanoTime();

    public Valley() {
        place.put("Каер - Морхен", CaerMorchen);
        place.put("печера Беса", Cave);

        place.put("Forest",Forest);


    }

    public void checkIntersection() {
        ReadOnlyObjectProperty<Bounds> first;
        ReadOnlyObjectProperty<Bounds> second;

        for (int i = 0; i < objects.length; i++) {
            for (int j = 0; j < objects.length; j++) {
                if (i != j) {
                    first = objects[i].pane.boundsInParentProperty();
                    second = objects[j].pane.boundsInParentProperty();
                    if (first.get().intersects(second.get())) {
                        objects[i].bonus(objects[j]);
                    }
                }
            }
        }
    }

    public void remove(int pos) {
        Yen[] tmp = new Yen[objects.length - 1];
        if (pos >= 0) System.arraycopy(objects, 0, tmp, 0, pos);
        if (objects.length - 1 - pos >= 0) System.arraycopy(objects, pos + 1, tmp, pos, objects.length - 1 - pos);
        objects = tmp;
    }

    public void lifeCycle() {
        long now = System.nanoTime();
        checkIntersection();
        Cave.lifeCycle();
        CaerMorchen.lifeCycle();
        Forest.lifeCycle();
        if (normalMode) {
            inUkraine();
            inPolish();
            inVin();
        }
        for (Yen p : objects) {
            if (now - p.time >= TimeUnit.SECONDS.toNanos(1)) {
                p.time = now;
                if (p.get_durability() > 0) p.set_durability(p.get_durability() - 1);
            }
            if (!p.isActive) p.autoMove();
        }

    }

    public void removeAllActive() {
        for (Yen hero2 : objects) {
            if (hero2.isActive) {

            }
        }
    }

    public void inUkraine() {
        Stack<Yen> toDelete = new Stack<>();
        for (Yen p : objects) {
            if (CaerMorchen.pane.boundsInParentProperty().get().contains(p.pane.boundsInParentProperty().get()) && p.get_durability() < Yen.DURABILITY_LIMIT) {
                toDelete.add(p);
            }
        }
        for (Yen p : toDelete) {
            remove(p);
            CaerMorchen.add(p);
        }

    }

    public void inPolish() {
        Stack<Yen> toDelete = new Stack<>();
        for (Yen p : objects) {
            if (Cave.pane.boundsInParentProperty().get().contains(p.pane.boundsInParentProperty().get()) && p.get_durability() < Yen.DURABILITY_LIMIT) {
                toDelete.add(p);
            }
        }
        for (Yen p : toDelete) {
            remove(p);
            Cave.add(p);
        }
    }
    public void inVin() {
        Stack<Yen> toDelete = new Stack<>();
        for (Yen p : objects) {
            if (Forest.pane.boundsInParentProperty().get().contains(p.pane.boundsInParentProperty().get()) && p.get_durability() < Yen.DURABILITY_LIMIT) {
                toDelete.add(p);
            }
        }
        for (Yen p : toDelete) {
            remove(p);
            Forest.add(p);
        }
    }

    public void remove(Yen hero2) {
        for (int i = 0; i < objects.length; i++) {
            if (objects[i].equals(hero2)) {
                remove(i);
                Main.labelWorld.setText("Кількість об'єктів: " + (Cave.objects.length + CaerMorchen.objects.length + Forest.objects.length+ objects.length));
                break;
            }
        }

    }

    public void add(Yen object, int pos) {
        Yen[] tmp = Arrays.copyOf(objects, objects.length + 1);
        for (int i = tmp.length - 1; i > pos; i--) {
            tmp[i] = tmp[i - 1];
        }
        tmp[pos] = object;
        objects = tmp;
    }

    public void add(Yen object) {
        Yen[] tmp = Arrays.copyOf(objects, objects.length + 1);
        tmp[objects.length] = object;
        objects = tmp;
        Main.labelWorld.setText("Кількість об'єктів: " + (Main.valley.Cave.objects.length + Main.valley.CaerMorchen.objects.length+ Main.valley.Forest.objects.length + Main.valley.objects.length));
    }

    @Override
    public String toString() {
        return "World:\n" +
                Arrays.toString(objects) +
                place.get("Forest").toString() +
                place.get("Cave").toString();
    }
}
